// Shiloh Mission College backend — admission application intake
// POST /api/apply  -> validates + stores an application, then emails admissions.
export const schema = `
CREATE TABLE IF NOT EXISTS applications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT,
  surname TEXT, other_names TEXT, age TEXT, gender TEXT, dob TEXT, pob TEXT,
  nationality TEXT, address TEXT, marital TEXT, email TEXT, phone TEXT, whatsapp TEXT,
  parent1 TEXT, parent2 TEXT, emergency TEXT, edu_bg TEXT,
  salvation_date TEXT, salvation_desc TEXT, denom TEXT, position TEXT,
  baptism_water_date TEXT, baptism_types TEXT, baptism_desc TEXT,
  calling TEXT, calling_detail TEXT, prev_training TEXT, current_ministry TEXT,
  reason TEXT, program TEXT, ref1_name TEXT, ref1_addr TEXT, ref1_phone TEXT,
  ref2_name TEXT, ref2_addr TEXT, ref2_phone TEXT,
  created_at TEXT
);
CREATE INDEX IF NOT EXISTS applications_user ON applications (user_id);
CREATE TABLE IF NOT EXISTS transcript_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT, tr_full_name TEXT, tr_maiden TEXT, tr_program TEXT, tr_year TEXT,
  tr_dob TEXT, tr_student_id TEXT, tr_email TEXT, tr_phone TEXT, tr_delivery TEXT,
  tr_address TEXT, tr_purpose TEXT, created_at TEXT
);
CREATE INDEX IF NOT EXISTS transcript_user ON transcript_requests (user_id);
`;

const ADMISSIONS_EMAIL = "info.shilohmissioncollege@gmail.com";
const REQUIRED = ["surname", "other_names", "email", "phone", "program"];

function clean(v) {
  return String(v == null ? "" : v).trim();
}

function isEmail(v) {
  return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (request.method === "POST" && url.pathname === "/api/apply") {
      const userId = request.headers.get("x-websim-user-id");
      let body;
      try { body = await request.json(); } catch { body = null; }
      if (!body) return Response.json({ error: "Invalid application data" }, { status: 400 });

      // Validate required fields
      for (const f of REQUIRED) {
        if (!clean(body[f])) {
          return Response.json({ error: "Missing required field: " + f }, { status: 400 });
        }
      }
      if (!isEmail(body.email)) {
        return Response.json({ error: "A valid email address is required" }, { status: 400 });
      }

      const app = {
        user_id: userId, surname: clean(body.surname), other_names: clean(body.other_names),
        age: clean(body.age), gender: clean(body.gender), dob: clean(body.dob), pob: clean(body.pob),
        nationality: clean(body.nationality), address: clean(body.address), marital: clean(body.marital),
        email: clean(body.email), phone: clean(body.phone), whatsapp: clean(body.whatsapp),
        parent1: clean(body.parent1), parent2: clean(body.parent2), emergency: clean(body.emergency),
        edu_bg: clean(body.edu_bg), salvation_date: clean(body.salvation_date),
        salvation_desc: clean(body.salvation_desc), denom: clean(body.denom), position: clean(body.position),
        baptism_water_date: clean(body.baptism_water_date), baptism_types: clean(body.baptism_types),
        baptism_desc: clean(body.baptism_desc), calling: clean(body.calling),
        calling_detail: clean(body.calling_detail), prev_training: clean(body.prev_training),
        current_ministry: clean(body.current_ministry), reason: clean(body.reason),
        program: clean(body.program), ref1_name: clean(body.ref1_name), ref1_addr: clean(body.ref1_addr),
        ref1_phone: clean(body.ref1_phone), ref2_name: clean(body.ref2_name),
        ref2_addr: clean(body.ref2_addr), ref2_phone: clean(body.ref2_phone),
        created_at: new Date().toISOString(),
      };

      await env.DB
        .prepare(
          `INSERT INTO applications (
            user_id, surname, other_names, age, gender, dob, pob, nationality, address, marital,
            email, phone, whatsapp, parent1, parent2, emergency, edu_bg, salvation_date,
            salvation_desc, denom, position, baptism_water_date, baptism_types, baptism_desc,
            calling, calling_detail, prev_training, current_ministry, reason, program,
            ref1_name, ref1_addr, ref1_phone, ref2_name, ref2_addr, ref2_phone, created_at
          ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
        )
        .bind(
          app.user_id, app.surname, app.other_names, app.age, app.gender, app.dob, app.pob,
          app.nationality, app.address, app.marital, app.email, app.phone, app.whatsapp,
          app.parent1, app.parent2, app.emergency, app.edu_bg, app.salvation_date,
          app.salvation_desc, app.denom, app.position, app.baptism_water_date, app.baptism_types,
          app.baptism_desc, app.calling, app.calling_detail, app.prev_training, app.current_ministry,
          app.reason, app.program, app.ref1_name, app.ref1_addr, app.ref1_phone, app.ref2_name,
          app.ref2_addr, app.ref2_phone, app.created_at
        )
        .run();

      // Attempt to deliver to the admissions inbox via FormSubmit (no secret key needed).
      // This is best-effort; the application is already stored safely in env.DB.
      let emailed = false;
      try {
        const lines = [];
        for (const [k, v] of Object.entries(body)) {
          if (v != null && String(v).trim()) lines.push(k.replace(/_/g, " ") + ": " + String(v).trim());
        }
        const payload = new URLSearchParams({
          _subject: "New SMC Application — " + app.surname + " " + app.other_names,
          _template: "table",
          _captcha: "false",
          _format: "text",
          text: lines.join("\n") + "\n\nApplication ID stored. Review in admissions records.",
        });
        await fetch("https://formsubmit.co/ajax/" + ADMISSIONS_EMAIL, {
          method: "POST",
          headers: { "content-type": "application/x-www-form-urlencoded", Accept: "application/json" },
          body: payload.toString(),
        });
        emailed = true;
      } catch {
        emailed = false;
      }

      return Response.json({ ok: true, emailed }, { status: 201 });
    }

    if (request.method === "POST" && url.pathname === "/api/transcript") {
      const userId = request.headers.get("x-websim-user-id");
      let body;
      try { body = await request.json(); } catch { body = null; }
      if (!body) return Response.json({ error: "Invalid transcript request" }, { status: 400 });

      const TR_REQUIRED = ["tr_full_name", "tr_program", "tr_year", "tr_dob", "tr_email", "tr_phone", "tr_delivery"];
      for (const f of TR_REQUIRED) {
        if (!clean(body[f])) {
          return Response.json({ error: "Missing required field: " + f }, { status: 400 });
        }
      }
      if (!isEmail(body.tr_email)) {
        return Response.json({ error: "A valid email address is required" }, { status: 400 });
      }

      const tr = {
        user_id: userId,
        tr_full_name: clean(body.tr_full_name), tr_maiden: clean(body.tr_maiden),
        tr_program: clean(body.tr_program), tr_year: clean(body.tr_year),
        tr_dob: clean(body.tr_dob), tr_student_id: clean(body.tr_student_id),
        tr_email: clean(body.tr_email), tr_phone: clean(body.tr_phone),
        tr_delivery: clean(body.tr_delivery), tr_address: clean(body.tr_address),
        tr_purpose: clean(body.tr_purpose), created_at: new Date().toISOString(),
      };

      await env.DB
        .prepare(
          `INSERT INTO transcript_requests (
            user_id, tr_full_name, tr_maiden, tr_program, tr_year, tr_dob, tr_student_id,
            tr_email, tr_phone, tr_delivery, tr_address, tr_purpose, created_at
          ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`
        )
        .bind(
          tr.user_id, tr.tr_full_name, tr.tr_maiden, tr.tr_program, tr.tr_year, tr.tr_dob,
          tr.tr_student_id, tr.tr_email, tr.tr_phone, tr.tr_delivery, tr.tr_address,
          tr.tr_purpose, tr.created_at
        )
        .run();

      let emailed = false;
      try {
        const lines = [];
        for (const [k, v] of Object.entries(body)) {
          if (v != null && String(v).trim()) lines.push(k.replace(/_/g, " ") + ": " + String(v).trim());
        }
        const payload = new URLSearchParams({
          _subject: "New Transcript Request — " + tr.tr_full_name,
          _template: "table",
          _captcha: "false",
          _format: "text",
          text: lines.join("\n") + "\n\nTranscript request stored in records database.",
        });
        await fetch("https://formsubmit.co/ajax/" + ADMISSIONS_EMAIL, {
          method: "POST",
          headers: { "content-type": "application/x-www-form-urlencoded", Accept: "application/json" },
          body: payload.toString(),
        });
        emailed = true;
      } catch {
        emailed = false;
      }

      return Response.json({ ok: true, emailed }, { status: 201 });
    }

    return new Response("Not found", { status: 404 });
  },
};