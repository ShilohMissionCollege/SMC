// SMC admission wizard + submission
(function () {
  const form = document.getElementById("applyForm");
  if (!form) return;

  const steps = Array.from(document.querySelectorAll(".form-step"));
  const track = document.getElementById("fpTrack");
  const msgBox = document.getElementById("formMsg");

  if (new URLSearchParams(location.search).get("submitted") === "1") {
    track.style.display = "none";
    form.style.display = "none";
    msgBox.style.display = "block";
    msgBox.innerHTML =
      "<h3 style='color:var(--green);margin-top:0'>&#10004; Thank you!</h3>" +
      "<p style='color:var(--ink);margin:0'>Your submission has been received. We will contact you soon.</p>";
    return;
  }
  const STEPS = steps.length;
  const SUBMIT_STEP = STEPS - 1;
  const stepLabels = ["Personal", "Contact", "Education", "Church", "Calling", "Ministry", "Program", "Confirm"];
  let cur = 0;

  const nav = document.createElement("div");
  nav.className = "form-actions form-nav";
  nav.innerHTML = `<div class="left"></div><div class="right"></div>`;
  form.appendChild(nav);

  function dots() {
    return Array.from(track.children);
  }

  function renderNav() {
    dots().forEach((d, i) => {
      d.className = "fp-dot " + (i < cur ? "done" : i === cur ? "act" : "");
    });
    steps.forEach((s, i) => s.classList.toggle("active", i === cur));
    window.scrollTo({ top: document.getElementById("apply").offsetTop - 90, behavior: "smooth" });
  }

  function valid(step) {
    const els = step.querySelectorAll("input, select, textarea");
    let ok = true;
    els.forEach((el) => {
      const required = el.hasAttribute("required");
      const bad = required && !el.value.trim();
      el.style.borderColor = bad ? "#c0392b" : "";
      if (bad) ok = false;
    });
    const email = document.getElementById("email");
    if (email && email.value && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email.value)) {
      email.style.borderColor = "#c0392b"; ok = false;
    }
    return ok;
  }

  function buildNavButtons() {
    const left = nav.querySelector(".left");
    const right = nav.querySelector(".right");
    left.innerHTML = "";
    right.innerHTML = "";

    if (cur > 0) {
      const back = document.createElement("button");
      back.type = "button";
      back.className = "btn btn-royal";
      back.textContent = "← Back";
      back.addEventListener("click", () => go(cur - 1));
      left.appendChild(back);
    }

    if (cur < SUBMIT_STEP) {
      const next = document.createElement("button");
      next.type = "button";
      next.className = "btn btn-gold";
      next.textContent = "Continue →";
      next.addEventListener("click", () => go(cur + 1));
      right.appendChild(next);
    } else {
      const dl = document.createElement("button");
      dl.id = "downloadBtn";
      dl.type = "button";
      dl.className = "btn btn-royal";
      dl.textContent = "⬇ Download My Form";
      dl.addEventListener("click", () => downloadFilledForm());
      right.appendChild(dl);

      const sub = document.createElement("button");
      sub.id = "submitBtn";
      sub.type = "submit";
      sub.className = "btn btn-gold";
      sub.textContent = "Submit Application";
      right.appendChild(sub);
    }
  }

  function go(n) {
    if (n === cur) return;
    if (n > cur && !valid(steps[cur])) return;
    cur = Math.max(0, Math.min(SUBMIT_STEP, n));
    renderNav();
    buildNavButtons();
  }

  // hide the static submit button in step markup (we build it dynamically)
  document.getElementById("submitBtn")?.remove();

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    if (cur !== SUBMIT_STEP) { go(SUBMIT_STEP); return; }
    if (!valid(steps[cur])) return;

    const agree = document.getElementById("agree");
    if (!agree.checked) { agree.style.outline = "2px solid #c0392b"; return; }

    const submitBtn = document.getElementById("submitBtn");
    submitBtn.disabled = true;
    submitBtn.textContent = "Submitting…";

    const next = document.createElement("input");
    next.type = "hidden";
    next.name = "_next";
    next.value = location.origin + location.pathname + "?submitted=1";
    form.appendChild(next);

    form.submit();
  });

  const photoInput = document.getElementById("photo");
  const photoPreview = document.getElementById("photoPreview");
  if (photoInput && photoPreview) {
    photoInput.addEventListener("change", () => {
      const file = photoInput.files && photoInput.files[0];
      if (!file) { photoPreview.hidden = true; return; }
      const reader = new FileReader();
      reader.onload = (e) => { photoPreview.src = e.target.result; photoPreview.hidden = false; };
      reader.readAsDataURL(file);
    });
  }

  const FIELD_LABELS = {
    photo: "Passport-sized Photo",
    surname: "Surname", other_names: "Other Names", age: "Age", gender: "Gender", dob: "Date of Birth",
    pob: "Place of Birth", nationality: "Nationality", address: "Postal Address", marital: "Marital Status",
    email: "Email Address", phone: "Personal Phone Number", whatsapp: "WhatsApp Number",
    parent1: "Parent / Guardian Name", parent2: "Other Parent / Guardian Name", emergency: "Emergency Contact Person",
    edu_bg: "Educational Background", salvation_date: "Date You Accepted Jesus", salvation_desc: "Description of Your Salvation Experience",
    denom: "Church Denomination", position: "Position Held in Church", baptism_water_date: "Water Baptism Date",
    baptism_types: "Baptism Types Experienced", baptism_desc: "Baptism Details", calling: "Calling",
    calling_detail: "Calling Details", prev_training: "Previous Theological Training",
    current_ministry: "Current Ministry & Activities", reason: "Reason for Attending SMC",
    program: "Program of Choice", ref1_name: "Reference 1 — Full Name", ref1_addr: "Reference 1 — Postal Address",
    ref1_phone: "Reference 1 — Mobile Number", ref2_name: "Reference 2 — Full Name",
    ref2_addr: "Reference 2 — Postal Address", ref2_phone: "Reference 2 — Mobile Number",
  };

  function downloadFilledForm() {
    const data = Object.fromEntries(new FormData(form).entries());
    const name = (data.surname || "Applicant") + " " + (data.other_names || "");

    const jsPDFLib = window.jspdf && window.jspdf.jsPDF;
    if (!jsPDFLib) {
      alert("PDF library is still loading. Please try again in a moment.");
      return;
    }

    const doc = new jsPDFLib();
    const pageW = doc.internal.pageSize.getWidth();
    const pageH = doc.internal.pageSize.getHeight();
    const pageBottom = pageH - 22;
    const margin = 22;
    const right = pageW - margin;

    // --- header ---
    let y = margin;
    doc.setFont("times", "bold");
    doc.setFontSize(24);
    doc.setTextColor("#173a7a");
    doc.text("Shiloh Mission College", pageW / 2, y, { align: "center" });
    y += 9;
    doc.setFont("times", "italic");
    doc.setFontSize(12);
    doc.setTextColor("#c9a227");
    doc.text("Admission Application Form — Apoginomai! Zao!", pageW / 2, y, { align: "center" });
    y += 7;
    doc.setDrawColor("#173a7a");
    doc.setLineWidth(0.6);
    doc.line(margin, y, right, y);
    y += 12;

    // --- attempts to read the passport photo as a data URL ---
    const photoFile = photoInput && photoInput.files && photoInput.files[0];
    if (photoFile) {
      const reader = new FileReader();
      reader.onload = (e) => {
        buildDoc(doc, data, name, margin, right, pageBottom, e.target.result);
      };
      reader.onerror = () => buildDoc(doc, data, name, margin, right, pageBottom, null);
      reader.readAsDataURL(photoFile);
    } else {
      buildDoc(doc, data, name, margin, right, pageBottom, null);
    }
  }

  function buildDoc(doc, data, name, margin, right, pageBottom, photoDataUrl) {
    const pageW = doc.internal.pageSize.getWidth();
    let y = margin + 12;
    let contentRight = right;

    if (photoDataUrl) {
      doc.addImage(photoDataUrl, "JPEG", right - 42, y - 2, 42, 50);
      contentRight = right - 58;
    }

    doc.setFont("times", "bold");
    doc.setFontSize(16);
    doc.setTextColor("#173a7a");
    doc.text("Applicant Details", margin, y);
    y += 7;

    const entries = Object.entries(FIELD_LABELS)
      .filter(([k]) => data[k] != null && typeof data[k] !== "object" && String(data[k]).trim())
      .map(([k, label]) => [label, String(data[k]).trim()]);

    for (const [label, value] of entries) {
      const fs = 11;
      doc.setFont("times", "bold");
      doc.setFontSize(fs);
      const labelW = doc.getStringUnitWidth(label) * fs / doc.internal.scaleFactor;
      const valLines = doc.splitTextToSize(value, contentRight - margin - labelW - 10);
      doc.setTextColor("#0d2653");
      doc.text(label + ":", margin, y);
      doc.setFont("times", "normal");
      doc.setTextColor("#24324a");
      doc.text(valLines, margin + labelW + 10, y);
      y += valLines.length * 5.5 + 5;
      if (y > pageBottom) {
        doc.addPage();
        y = margin + 6;
      }
    }

    // --- footer note on the final page ---
    const note = "This is a record of the application form as filled by the applicant on " +
      new Date().toLocaleDateString() + ". Submitted to the Admissions Office of Shiloh Mission College. — " + name + ".";
    doc.setFont("times", "normal");
    doc.setFontSize(9);
    doc.setTextColor("#5a6a85");
    const wrapped = doc.splitTextToSize(note, right - margin);
    let ny = doc.internal.pageSize.getHeight() - 22;
    for (let i = wrapped.length - 1; i >= 0; i--) {
      doc.text(wrapped[i], margin, ny);
      ny -= 5;
    }

    doc.save("SMC_Application_" + (data.surname || "Applicant").replace(/[^a-z0-9]+/gi, "_") + ".pdf");
  }

  (function buildTrack() {
    stepLabels.forEach((l, i) => {
      const dot = document.createElement("div");
      dot.className = "fp-dot" + (i === 0 ? " act" : "");
      dot.title = l;
      track.appendChild(dot);
    });
  })();

  renderNav();
  buildNavButtons();
})();