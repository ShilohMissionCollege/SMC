// SMC transcript request handler
(function () {
  const form = document.getElementById("trForm");
  if (!form) return;
  const msgBox = document.getElementById("trMsg");
  const submitBtn = document.getElementById("trSubmitBtn");

  if (new URLSearchParams(location.search).get("submitted") === "1") {
    form.style.display = "none";
    msgBox.style.display = "block";
    msgBox.innerHTML =
      "<h3 style='color:var(--green);margin-top:0'>&#10004; Thank you!</h3>" +
      "<p style='color:var(--ink);margin:0'>Your submission has been received. We will contact you soon.</p>";
    return;
  }

  // Populate years (from 20 years ago to current)
  const yearSel = document.getElementById("tr_year");
  const currentYear = new Date().getFullYear();
  for (let y = currentYear; y >= currentYear - 20; y--) {
    const opt = document.createElement("option");
    opt.value = y;
    opt.textContent = y;
    yearSel.appendChild(opt);
  }

  function valid() {
    const els = form.querySelectorAll("input, select, textarea");
    let ok = true;
    els.forEach((el) => {
      const required = el.hasAttribute("required");
      const bad = required && !el.value.trim();
      el.style.borderColor = bad ? "#c0392b" : "";
      if (bad) ok = false;
    });
    const email = document.getElementById("tr_email");
    if (email && email.value && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email.value)) {
      email.style.borderColor = "#c0392b"; ok = false;
    }
    return ok;
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    if (!valid()) return;

    const consent = document.getElementById("tr_consent");
    if (!consent.checked) { consent.style.outline = "2px solid #c0392b"; return; }

    submitBtn.disabled = true;
    submitBtn.textContent = "Submitting…";

    const next = document.createElement("input");
    next.type = "hidden";
    next.name = "_next";
    next.value = location.origin + location.pathname + "?submitted=1";
    form.appendChild(next);

    form.submit();
  });
})();