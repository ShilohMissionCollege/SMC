// Shared header + footer injection for SMC site
(function () {
  const LINKS = [
    { href: "index.html", label: "Home" },
    { href: "about.html", label: "About" },
    { href: "academics.html", label: "Academics" },
    { href: "admissions.html", label: "Admissions" },
    { href: "life.html", label: "Student Life" },
    { href: "alumni.html", label: "Alumni" },
    { href: "give.html", label: "Give" },
  ];

  const contact = {
    phone1: "+233 599 442 039",
    phone2: "+233 242 079 888",
    wa: "233599442039",
    email: "info.shilohmissioncollege@gmail.com",
  };

  const current = location.pathname.split("/").pop() || "index.html";

  const header = document.createElement("header");
  header.className = "site-header";
  header.innerHTML = `
    <div class="topbar">
      <div class="wrap">
        <span class="motto">Apoginomai! Zao! &mdash; To Die Is To Live</span>
        <span class="top-contact">
          <span class="phone"><a href="tel:${contact.phone1.replace(/\s/g, "")}">${contact.phone1}</a> <span class="sep">/</span> <a href="tel:${contact.phone2.replace(/\s/g, "")}">${contact.phone2}</a></span>
          <span class="sep">·</span>
          <a href="mailto:${contact.email}">info.shilohmissioncollege@gmail.com</a>
        </span>
      </div>
    </div>
    <div class="wrap">
      <nav class="navbar">
        <a class="brand" href="index.html">
          <mark>A</mark>
          <span class="brand-name">Shiloh Mission College<small>Apoginomai! Zao!</small></span>
        </a>
        <button class="hamburger" aria-label="Menu" id="hamburger">
          <span></span><span></span><span></span>
        </button>
        <ul class="nav-links" id="navLinks">
          ${LINKS.map((l) => `<li><a href="${l.href}" class="${l.href === current ? "active" : ""}">${l.label}</a></li>`).join("")}
        </ul>
        <a class="btn btn-gold nav-cta" href="admissions.html#apply">Apply Now</a>
      </nav>
    </div>
  `;

  const footer = document.createElement("footer");
  footer.className = "site-footer";
  footer.innerHTML = `
    <div class="wrap">
      <div class="footer-grid">
        <div>
          <a class="brand" href="index.html" style="color:#fff">
            <mark style="background:linear-gradient(135deg,var(--gold),var(--gold-light));color:#3b2d04">A</mark>
            <span class="brand-name" style="color:#fff">Shiloh Mission College</span>
          </a>
          <p style="margin-top:.9rem;font-size:.92rem">A Holy Spirit-driven school of Apostolic Theology &amp; Missiology &mdash; making disciples and equipping workers for the harvest since 2006.</p>
          <p class="motto" style="color:var(--gold-light);font-family:var(--serif);font-style:italic;margin:0">"Apoginomai! Zao!" &mdash; To Die Is To Live (Rom. 12:1)</p>
          <div class="social">
            <a href="#" aria-label="WhatsApp" title="WhatsApp"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M17.5 14.4c-.3-.15-1.8-.9-2-.99-.3-.15-.5-.22-.7.22-.2.44-.8 1-.9 1.14-.2.22-.4.29-.7.15-.9-.45-1.9-1-2.6-1.85-.3-.38-.6-.85-.9-1.3-.3-.45-.7-1.2-.55-1.25.1-.13.6-.72.86-1 .16-.2.18-.3.27-.5.09-.2.05-.4-.02-.55-.08-.15-.7-1.8-.95-2.4-.25-.6-.5-.5-.7-.5h-.6c-.2 0-.5.07-.78.37-.27.3-1.05 1-1.05 2.4 0 1.42 1 2.78 1.2 3 .2.22 2 3.2 4.9 4.42.7.3 1.3.48 1.7.62.7.23 1.4.2 1.9.12.6-.09 1.8-.75 2.05-1.45.25-.72.25-1.3.18-1.43-.07-.13-.25-.26-.55-.4zM12.05 3C7 3 2.85 7.13 2.85 12.2c0 1.6.43 3.2 1.24 4.6L3 21l4.3-1.1a9.2 9.2 0 0 0 4.75 1.3h.01c5.05 0 9.2-4.13 9.2-9.2 0-2.5-.95-4.83-2.7-6.6A9.05 9.05 0 0 0 12.05 3z"/></svg></a>
            <a href="mailto:${contact.email}" aria-label="Email" title="Email"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M20 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 4-8 5-8-5V6l8 5 8-5z"/></svg></a>
            <a href="https://www.facebook.com/share/1BGaFcCXdf/" target="_blank" rel="noopener" aria-label="Facebook" title="Facebook"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M22 12a10 10 0 1 0-11.56 9.88v-6.99H7.9V12h2.54V9.8c0-2.5 1.49-3.89 3.77-3.89 1.09 0 2.23.2 2.23.2v2.46h-1.26c-1.24 0-1.63.77-1.63 1.56V12h2.78l-.45 2.89h-2.33v6.99A10 10 0 0 0 22 12z"/></svg></a>
            <a href="https://www.youtube.com/@ShilohMissionCollege" target="_blank" rel="noopener" aria-label="YouTube" title="YouTube"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M23.5 6.19a3.02 3.02 0 0 0-2.12-2.14C19.5 3.55 12 3.55 12 3.55s-7.5 0-9.38.5A3.02 3.02 0 0 0 .5 6.19C0 8.07 0 12 0 12s0 3.93.5 5.81a3.02 3.02 0 0 0 2.12 2.14c1.88.5 9.38.5 9.38.5s7.5 0 9.38-.5a3.02 3.02 0 0 0 2.12-2.14C24 15.93 24 12 24 12s0-3.93-.5-5.81zM9.55 15.57V8.43L15.82 12l-6.27 3.57z"/></svg></a>
          </div>
        </div>
        <div>
          <h4>Explore</h4>
          <ul>
            ${LINKS.map((l) => `<li><a href="${l.href}">${l.label}</a></li>`).join("")}
          </ul>
        </div>
        <div>
          <h4>Quick Info</h4>
          <ul>
            <li><a href="about.html#faith">Statement of Faith</a></li>
            <li><a href="academics.html">Programs</a></li>
            <li><a href="life.html#library">Library &amp; Resources</a></li>
            <li><a href="alumni.html">Alumni &amp; Transcripts</a></li>
            <li><a href="admissions.html#fees">Financial Policy</a></li>
            <li><a href="give.html">Give / Support</a></li>
          </ul>
        </div>
        <div>
          <h4>Contact Us</h4>
          <div class="contact-line">📞 <a href="tel:${contact.phone1.replace(/\s/g, "")}">${contact.phone1}</a></div>
          <div class="contact-line">📞 <a href="tel:${contact.phone2.replace(/\s/g, "")}">${contact.phone2}</a></div>
          <div class="contact-line">💬 <a href="https://wa.me/${contact.wa}" target="_blank" rel="noopener">WhatsApp Us</a></div>
          <div class="contact-line">✉️ <a href="mailto:${contact.email}">${contact.email}</a></div>
          <div class="contact-line">📍 Atimpoku, Adomi Bridge City, off Akosombo Rd, Ghana</div>
        </div>
      </div>
      <div class="copyright">
        &copy; <span id="year"></span> Shiloh Mission College (SMC). Glory to God. &mdash; "Freely we have received, freely give."
      </div>
    </div>
  `;

  document.body.prepend(header);
  document.body.appendChild(footer);

  document.getElementById("year").textContent = new Date().getFullYear();

  const hamburger = document.getElementById("hamburger");
  const navLinks = document.getElementById("navLinks");
  hamburger.addEventListener("click", () => navLinks.classList.toggle("open"));
  navLinks.addEventListener("click", (e) => {
    if (e.target.tagName === "A") navLinks.classList.remove("open");
  });
})();